#!/usr/bin/env bash
# ORCA | build the whole Hive warehouse from scratch.
# Usage:  bash hive/scripts/run_all.sh                     (uses the `hive` CLI)
#         BEELINE_URL=jdbc:hive2://host:10000 bash hive/scripts/run_all.sh   (uses beeline)
# Never put passwords in this file - pass them through the environment (BEELINE_USER / BEELINE_PASS).
set -euo pipefail
cd "$(dirname "$0")/.."

run() {
  echo ">>> $1"
  if [[ -n "${BEELINE_URL:-}" ]]; then
    beeline -u "$BEELINE_URL" ${BEELINE_USER:+-n "$BEELINE_USER"} ${BEELINE_PASS:+-p "$BEELINE_PASS"} -f "$1"
  else
    hive -f "$1"
  fi
}

for f in 00_setup.hql 01_raw_tables.hql 02_clean_tables.hql 03_views.hql 04_risk_marts.hql; do run "$f"; done
echo "Warehouse built. Run the analysis with: bash hive/scripts/run_queries.sh"
