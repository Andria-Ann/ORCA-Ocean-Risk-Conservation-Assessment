#!/usr/bin/env bash
# ORCA | copy the CSVs produced by data/prepare_csv.py into HDFS, one directory per raw table.
# Usage: bash hive/scripts/load_to_hdfs.sh data/csv
# (Nayana owns the HDFS cluster setup - this script only needs `hdfs dfs` on the PATH.)
set -euo pipefail
SRC="${1:-data/csv}"
BASE="/user/orca/raw"

# csv file name -> raw table directory (must match LOCATION in 01_raw_tables.hql)
declare -A MAP=(
  [dim_country]=dim_country [dim_area]=dim_area [dim_environment]=dim_environment
  [dim_measure]=dim_measure [dim_species]=dim_species [dim_status]=dim_status
  [fact_capture]=fact_capture [fact_aquaculture]=fact_aquaculture
  [ocean_climate]=ocean_climate [coral_cleaned]=coral [economy_cleaned]=economy
  [chlorophyll_cleaned]=chlorophyll [cast_cleaned]=cast
  [global_plastics_production]=global_plastics_production
  [mismanaged_waste_global]=mismanaged_waste_global
  [per_capita_mismanaged_plastic]=per_capita_mismanaged_plastic
  [per_capita_plastic_waste_gdp]=per_capita_plastic_waste_gdp
  [plastic_waste_per_capita]=plastic_waste_per_capita
)

for f in "${!MAP[@]}"; do
  dir="${BASE}/${MAP[$f]}"
  [[ -f "${SRC}/${f}.csv" ]] || { echo "missing ${SRC}/${f}.csv" >&2; exit 1; }
  hdfs dfs -mkdir -p "${dir}"
  hdfs dfs -put -f "${SRC}/${f}.csv" "${dir}/${f}.csv"
  echo "loaded ${f} -> ${dir}"
done
hdfs dfs -ls -R "${BASE}" | head -50
