#!/usr/bin/env bash
# ORCA | run every analytical query and save the output next to the project report.
# Usage: bash hive/scripts/run_queries.sh [output_dir]
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="${1:-../docs/query_results}"
mkdir -p "$OUT"
for q in queries/q*.hql; do
  name=$(basename "$q" .hql)
  echo ">>> $name"
  if [[ -n "${BEELINE_URL:-}" ]]; then
    beeline -u "$BEELINE_URL" ${BEELINE_USER:+-n "$BEELINE_USER"} ${BEELINE_PASS:+-p "$BEELINE_PASS"} \
            --outputformat=table -f "$q" > "$OUT/$name.txt"
  else
    hive -f "$q" > "$OUT/$name.txt"
  fi
done
