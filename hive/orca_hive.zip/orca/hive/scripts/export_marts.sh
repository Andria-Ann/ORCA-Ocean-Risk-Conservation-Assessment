#!/usr/bin/env bash
# ORCA | export the risk marts to CSV *with header* for the clustering (Python) and dashboard (React) teams.
# Usage: BEELINE_URL=jdbc:hive2://host:10000 bash hive/scripts/export_marts.sh [output_dir]
# Output files: mart_country_exposure.csv, mart_climate_location_risk.csv, mart_coral_site_risk.csv,
#               mart_fish_area_trend.csv, mart_marine_economy_sector.csv
set -euo pipefail
OUT="${1:-../analytics/input}"
mkdir -p "$OUT"
: "${BEELINE_URL:?set BEELINE_URL, e.g. jdbc:hive2://localhost:10000}"
for t in mart_country_exposure mart_climate_location_risk mart_coral_site_risk mart_fish_area_trend mart_marine_economy_sector; do
  beeline -u "$BEELINE_URL" ${BEELINE_USER:+-n "$BEELINE_USER"} ${BEELINE_PASS:+-p "$BEELINE_PASS"} \
          --outputformat=csv2 --silent=true -e "SELECT * FROM orca.${t}" > "${OUT}/${t}.csv"
  echo "exported ${t}"
done
