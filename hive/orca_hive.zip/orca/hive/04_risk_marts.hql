-- =============================================================================
-- ORCA | Hive layer 4: RISK MARTS (feed clustering + dashboard)
-- Owner: Siva Pournami PB (Hive)
--
-- Each mart is a small, final table. Scores are 0-1 (percent_rank based, so they are
-- relative rankings inside the dataset, not absolute probabilities). Weights are written
-- in the SQL so the team can tune them in one place.
--   mart_fish_area_trend         FAO marine area x year: capture, YoY, drop from peak
--   mart_country_exposure        country: pollution pressure + fishery dependence + vulnerability
--   mart_climate_location_risk   reef location (ocean_climate): heat, acidity, bleaching, heatwaves
--   mart_coral_site_risk         Palk Bay monitoring site: DHW stress, bleaching, ENSO exposure
--   mart_marine_economy_sector   sector x year: GDP, jobs, growth
-- =============================================================================

USE orca;

-- ------------------------------------------------------------ fish area trend
DROP TABLE IF EXISTS mart_fish_area_trend;
CREATE TABLE mart_fish_area_trend STORED AS ORC AS
SELECT t.prod_year, t.area_id, t.area_name, t.ocean_name, t.tonnes,
       t.prev_tonnes,
       CASE WHEN t.prev_tonnes > 0 THEN ROUND((t.tonnes - t.prev_tonnes) / t.prev_tonnes * 100, 2) END AS yoy_pct,
       t.peak_tonnes,
       CASE WHEN t.peak_tonnes > 0 THEN ROUND((t.peak_tonnes - t.tonnes) / t.peak_tonnes * 100, 2) END AS pct_below_peak
FROM (
  SELECT prod_year, area_id, area_name, ocean_name, tonnes,
         LAG(tonnes) OVER (PARTITION BY area_id ORDER BY prod_year) AS prev_tonnes,
         MAX(tonnes) OVER (PARTITION BY area_id ORDER BY prod_year
                           ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS peak_tonnes
  FROM vw_marine_capture_area_year
) t;

-- ------------------------------------------------------- country exposure mart
-- Risk = pollution pressure (35%) + fishery dependence (25%) + capture decline (20%)
--        + economic vulnerability (20%)
DROP TABLE IF EXISTS mart_country_exposure;
CREATE TABLE mart_country_exposure STORED AS ORC AS
WITH cap AS (
  SELECT country_id,
         AVG(CASE WHEN yr BETWEEN 2020 AND 2024 THEN yr_tonnes END) AS recent_capture_t,
         AVG(CASE WHEN yr BETWEEN 2010 AND 2014 THEN yr_tonnes END) AS baseline_capture_t
  FROM (
    SELECT country_id, prod_year AS yr, SUM(tonnes_live_weight) AS yr_tonnes
    FROM fact_capture
    WHERE environment_id = 'MA' AND prod_year BETWEEN 2010 AND 2024
    GROUP BY country_id, prod_year
  ) y
  GROUP BY country_id
),
base AS (
  SELECT c.country_id, c.country_name, p.iso3, c.continent, c.geo_region, c.economic_class,
         p.mismanaged_pct_of_global, p.plastic_waste_kg_pp_day, p.mismanaged_kg_pp_day,
         p.gdp_per_capita_ppp, p.population,
         COALESCE(k.recent_capture_t, 0)   AS recent_capture_t,
         COALESCE(k.baseline_capture_t, 0) AS baseline_capture_t,
         CASE WHEN k.baseline_capture_t > 0
              THEN ROUND((k.recent_capture_t - k.baseline_capture_t) / k.baseline_capture_t * 100, 2) END AS capture_trend_pct
  FROM plastic_country_2010 p
  JOIN dim_country c ON p.iso3 = c.iso3
  LEFT JOIN cap k    ON c.country_id = k.country_id
),
scored AS (
  SELECT b.*,
         PERCENT_RANK() OVER (ORDER BY COALESCE(mismanaged_pct_of_global, 0)) AS pollution_score,
         PERCENT_RANK() OVER (ORDER BY recent_capture_t)                      AS dependence_score,
         PERCENT_RANK() OVER (ORDER BY COALESCE(-capture_trend_pct, 0))       AS decline_score,
         1 - PERCENT_RANK() OVER (ORDER BY COALESCE(gdp_per_capita_ppp, 0))   AS vulnerability_score
  FROM base b
)
SELECT s.*,
       ROUND(0.35 * pollution_score + 0.25 * dependence_score
           + 0.20 * decline_score   + 0.20 * vulnerability_score, 4) AS risk_score,
       CASE NTILE(4) OVER (ORDER BY 0.35 * pollution_score + 0.25 * dependence_score
                                   + 0.20 * decline_score   + 0.20 * vulnerability_score)
            WHEN 4 THEN 'Critical' WHEN 3 THEN 'High' WHEN 2 THEN 'Moderate' ELSE 'Low' END AS risk_tier
FROM scored s;

-- -------------------------------------------------- reef location climate risk
-- Risk = heat (30%) + bleaching (30%) + acidification (20%) + heatwaves (20%)
DROP TABLE IF EXISTS mart_climate_location_risk;
CREATE TABLE mart_climate_location_risk STORED AS ORC AS
WITH agg AS (
  SELECT location_name,
         COUNT(*)                              AS observations,
         ROUND(AVG(latitude), 3)               AS avg_latitude,
         ROUND(AVG(longitude), 3)              AS avg_longitude,
         ROUND(AVG(sst_c), 2)                  AS avg_sst_c,
         ROUND(MAX(sst_c), 2)                  AS max_sst_c,
         ROUND(AVG(ph_level), 3)               AS avg_ph,
         ROUND(MIN(ph_level), 3)               AS min_ph,
         ROUND(AVG(species_observed), 1)       AS avg_species_observed,
         ROUND(AVG(CASE WHEN marine_heatwave THEN 1.0 ELSE 0.0 END), 4) AS heatwave_share,
         -- bleaching share is computed on records with a known severity only
         ROUND(CAST(SUM(CASE WHEN bleaching_severity = 'High' THEN 1 ELSE 0 END) AS DOUBLE)
               / NULLIF(SUM(CASE WHEN bleaching_severity <> 'Unknown' THEN 1 ELSE 0 END), 0), 4) AS high_bleaching_share,
         ROUND(CAST(SUM(CASE WHEN bleaching_severity = 'Unknown' THEN 1 ELSE 0 END) AS DOUBLE) / COUNT(*), 4)   AS unknown_severity_share
  FROM ocean_climate
  GROUP BY location_name
),
scored AS (
  SELECT a.*,
         PERCENT_RANK() OVER (ORDER BY avg_sst_c)                          AS heat_score,
         PERCENT_RANK() OVER (ORDER BY COALESCE(high_bleaching_share, 0))  AS bleaching_score,
         1 - PERCENT_RANK() OVER (ORDER BY avg_ph)                         AS acidity_score,
         PERCENT_RANK() OVER (ORDER BY heatwave_share)                     AS heatwave_score
  FROM agg a
)
SELECT s.*,
       ROUND(0.30 * heat_score + 0.30 * bleaching_score + 0.20 * acidity_score + 0.20 * heatwave_score, 4) AS risk_score,
       CASE WHEN 0.30 * heat_score + 0.30 * bleaching_score + 0.20 * acidity_score + 0.20 * heatwave_score >= 0.60 THEN 'High'
            WHEN 0.30 * heat_score + 0.30 * bleaching_score + 0.20 * acidity_score + 0.20 * heatwave_score >= 0.35 THEN 'Medium'
            ELSE 'Low' END AS risk_tier
FROM scored s;

-- --------------------------------------------------------- coral site risk
-- Risk = DHW heat stress (35%) + bleaching % (35%) + share of bleached months (20%) + turbidity (10%)
DROP TABLE IF EXISTS mart_coral_site_risk;
CREATE TABLE mart_coral_site_risk STORED AS ORC AS
WITH agg AS (
  SELECT site_name,
         COUNT(*)                                  AS observations,
         ROUND(AVG(latitude), 4)                   AS avg_latitude,
         ROUND(AVG(longitude), 4)                  AS avg_longitude,
         ROUND(AVG(temperature_c), 2)              AS avg_temp_c,
         ROUND(AVG(dhw_stress), 3)                 AS avg_dhw,
         ROUND(MAX(dhw_stress), 3)                 AS max_dhw,
         ROUND(AVG(bleaching_percent), 2)          AS avg_bleaching_pct,
         ROUND(AVG(CASE WHEN damage_state IN ('bleached', 'severe_bleach') THEN 1.0 ELSE 0.0 END), 4) AS bleached_share,
         ROUND(AVG(CASE WHEN enso_phase = 'El Nino' THEN 1.0 ELSE 0.0 END), 4)                        AS el_nino_share,
         ROUND(AVG(ph), 3)                         AS avg_ph,
         ROUND(AVG(turbidity_ntu), 3)              AS avg_turbidity_ntu
  FROM coral_monitoring
  GROUP BY site_name
),
scored AS (
  SELECT a.*,
         PERCENT_RANK() OVER (ORDER BY avg_dhw)           AS stress_score,
         PERCENT_RANK() OVER (ORDER BY avg_bleaching_pct) AS bleaching_score,
         PERCENT_RANK() OVER (ORDER BY bleached_share)    AS damage_score,
         PERCENT_RANK() OVER (ORDER BY avg_turbidity_ntu) AS turbidity_score
  FROM agg a
)
SELECT s.*,
       ROUND(0.35 * stress_score + 0.35 * bleaching_score + 0.20 * damage_score + 0.10 * turbidity_score, 4) AS risk_score,
       CASE WHEN 0.35 * stress_score + 0.35 * bleaching_score + 0.20 * damage_score + 0.10 * turbidity_score >= 0.60 THEN 'High'
            WHEN 0.35 * stress_score + 0.35 * bleaching_score + 0.20 * damage_score + 0.10 * turbidity_score >= 0.35 THEN 'Medium'
            ELSE 'Low' END AS risk_tier
FROM scored s;

-- --------------------------------------------------- marine economy by sector
DROP TABLE IF EXISTS mart_marine_economy_sector;
CREATE TABLE mart_marine_economy_sector STORED AS ORC AS
SELECT w.*,
       LAG(gdp_usd_thousand) OVER (PARTITION BY category ORDER BY obs_year) AS prev_gdp_usd_thousand,
       CASE WHEN LAG(gdp_usd_thousand) OVER (PARTITION BY category ORDER BY obs_year) > 0
            THEN ROUND((gdp_usd_thousand / LAG(gdp_usd_thousand) OVER (PARTITION BY category ORDER BY obs_year) - 1) * 100, 2)
       END AS gdp_yoy_pct
FROM vw_marine_economy_wide w;
