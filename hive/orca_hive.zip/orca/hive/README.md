# hive/ — ORCA data warehouse and analytical queries
Owner: **Siva Pournami PB** (Hive and analytical queries)

Hive turns the raw HDFS files (Nayana) into clean, typed, queryable tables, answers the analytical
questions, and publishes small **risk marts** that the clustering (Anavadhya) and dashboard (Andria)
teams consume. Spark (Helna) can read the same ORC tables through the Hive metastore.

```
Datas.xlsx ─ data/prepare_csv.py ─▶ CSV ─ scripts/load_to_hdfs.sh ─▶ HDFS /user/orca/raw/<table>/
   raw_*  (external, all STRING)   01_raw_tables.hql
   clean  (typed ORC)              02_clean_tables.hql   dims, partitioned facts, climate, coral, economy ...
   views                           03_views.hql          vw_fish_production, vw_marine_capture_area_year ...
   marts  (risk scores)            04_risk_marts.hql     mart_country_exposure, mart_*_risk ...
   queries/q01..q09                analysis
   scripts/export_marts.sh ─▶ CSV for analytics/ (clustering) and frontend/ (dashboard)
```

## Run order
```bash
python3 data/prepare_csv.py Datas.xlsx data/csv      # 1. xlsx -> csv (needs pandas, openpyxl)
bash hive/scripts/load_to_hdfs.sh data/csv           # 2. put csv in HDFS
bash hive/scripts/run_all.sh                         # 3. 00..04 .hql  (BEELINE_URL=jdbc:hive2://host:10000 to use beeline)
bash hive/scripts/run_queries.sh docs/query_results  # 4. run q01..q09, save output for the report
BEELINE_URL=... bash hive/scripts/export_marts.sh analytics/input   # 5. hand marts to the team
```
Credentials: pass `BEELINE_USER` / `BEELINE_PASS` as environment variables; nothing secret is stored in the repo.
Written for Hive 3.x (ORC, window functions, CTE in CTAS). Not yet executed on a real cluster – see "Testing without a cluster" below.

## Tables
| Layer | Table | Rows | Notes |
|---|---|---|---|
| dim | dim_country, dim_area, dim_species, dim_environment, dim_measure, dim_status | 251 / 19 / 9,531 / 4 / 5 / 16 | FAO-style dimensions |
| fact | fact_capture, fact_aquaculture | 107,419 each | tonnes live weight, partitioned by `prod_year` (1950-2024) |
| obs | ocean_climate | 500 | 7 reef locations 2015+: SST, pH, bleaching severity, heatwave flag |
| obs | coral_monitoring | 2,000 | 8 Palk Bay sites 2000+: DHW stress, bleaching %, ENSO, water quality |
| obs | marine_economy | 714 | sector x year x variable, 2007-2021 |
| obs | plankton_profile | 263 | Southern Ocean bacteria / phytoplankton by depth |
| obs | ocean_casts | 34,404 | CalCOFI-style cast archive 1949-2016 (22 of 61 columns kept) |
| plastic | plastic_country_2010, plastic_production_global | 186 / 66 | mismanaged waste, per-capita waste, GDP, population |
| views | vw_fish_production, vw_marine_capture_area_year, vw_marine_economy_wide | | |
| marts | mart_fish_area_trend, mart_country_exposure, mart_climate_location_risk, mart_coral_site_risk, mart_marine_economy_sector | | |

## Risk scores (all 0-1, percent-rank based = relative ranking inside this dataset)
* **Country** = 0.35 plastic pollution + 0.25 fishery dependence + 0.20 capture decline (2010-14 → 2020-24) + 0.20 low-GDP vulnerability; quartile tiers Low / Moderate / High / Critical.
* **Reef location** = 0.30 heat (avg SST) + 0.30 high-bleaching share + 0.20 acidity (low pH) + 0.20 heatwave share; tiers at 0.35 / 0.60.
* **Coral site** = 0.35 avg DHW + 0.35 avg bleaching % + 0.20 bleached share + 0.10 turbidity.
Weights live in `04_risk_marts.hql` — change them there and re-run. They are a starting point for the team to agree on, not a validated model.

## Analytical queries
| File | Question |
|---|---|
| q01_data_quality | counts, orphan keys, status flags, nulls, duplicate sheets |
| q02_fisheries_trends | production by decade, top countries, winners/losers, ocean basin share |
| q03_species_concentration | top species, top-10 concentration, group change, steepest declines |
| q04_area_decline_detection | YoY, drop from peak, consecutive-decline flags, 5-yr rolling |
| q05_climate_coral_risk | SST/pH/bleaching/heatwave links, DHW bands, ENSO effect, correlations |
| q06_plastic_pollution | top polluters, income/region, GDP bands, hotspots with high catch |
| q07_marine_economy | sector GDP/jobs, CAGR, ecosystem-dependent value, loss scenarios |
| q08_plankton_and_casts | microbes by depth, transects, cast archive coverage |
| q09_risk_ranking | dashboard-ready rankings from the marts |

## Data issues found (please read before the report)
1. **`fact_capture` and `fact_aquaculture` are identical** in the workbook (107,419 rows, every value equal — q01 #2). One sheet is a copy of the other.
2. **The "capture" content looks like aquaculture**: top species are Japanese kelp, carpet shell, wakame, Atlantic salmon, and China is ~69 % of 2024 "marine capture". Wild capture is probably missing; re-export both from FAO FishStat (Global Capture / Global Aquaculture Production) before drawing conclusions about wild stocks.
3. 25 % of fact rows use species ids absent from `dim_species` (e.g. OYC, EMX, GLS); queries keep them as `UNMAPPED:<id>` instead of dropping them.
4. 54 % of fact rows use inland FAO areas (not in `dim_area`); 76 marine rows point at inland area ids 2/4/5/7.
5. `ocean_climate.bleaching_severity` is 30 % `Unkown` (typo fixed to `Unknown`); bleaching shares are computed on known values only.
6. Plastic data is a single year (2010); `OWID_CIS` (Channel Islands) has no match in `dim_country`.
7. 2020s "decade" totals cover 5 years only — compare decades with care.
8. Hive caveat: `CAST('False' AS BOOLEAN)` is not reliable, so booleans are parsed with `LOWER(x) = 'true'`.

## Testing without a cluster
`python3 hive/tests/local_sqlite_check.py data/csv` mirrors the clean layer in SQLite and runs views, marts and all queries (0 errors at hand-over). It validates logic, not Hive-specific DDL (raw tables, ORC, partitioning) — run `run_all.sh` on the cluster for that.
