-- =============================================================================
-- ORCA | Hive layer 2: CLEAN tables (typed, de-duplicated names, ORC)
-- Owner: Siva Pournami PB (Hive)
--
-- Reads raw_* (all STRING) and writes typed ORC tables.
-- Cleaning rules applied here (raw data stays untouched):
--   * empty strings -> NULL, text trimmed
--   * numbers / dates cast to proper types
--   * ocean_climate.bleaching_severity: typo 'Unkown' -> 'Unknown'
--   * marine_heatwave 'True'/'False' text -> BOOLEAN (CAST(text AS BOOLEAN) is NOT safe in Hive)
--   * cast_cleaned (61 columns): only the 22 columns that are actually populated are kept
--   * fact tables are partitioned by production year
-- Run after 01_raw_tables.hql and after the CSVs are in HDFS.
-- =============================================================================

USE orca;
SET hive.exec.dynamic.partition = true;
SET hive.exec.dynamic.partition.mode = nonstrict;

-- ---------------------------------------------------------------- dimensions
DROP TABLE IF EXISTS dim_country;
CREATE TABLE dim_country STORED AS ORC AS
SELECT CAST(country_id AS INT)            AS country_id,
       NULLIF(TRIM(country_name), '')     AS country_name,
       NULLIF(TRIM(iso2), '')             AS iso2,
       NULLIF(TRIM(iso3), '')             AS iso3,
       NULLIF(TRIM(continent), '')        AS continent,
       NULLIF(TRIM(geo_region), '')       AS geo_region,
       NULLIF(TRIM(economic_class), '')   AS economic_class,
       NULLIF(TRIM(official_name), '')    AS official_name
FROM raw_dim_country;

DROP TABLE IF EXISTS dim_area;
CREATE TABLE dim_area STORED AS ORC AS
SELECT CAST(area_id AS INT) AS area_id, TRIM(area_name) AS area_name,
       TRIM(inland_marine) AS inland_marine, TRIM(fa_region) AS fa_region, TRIM(ocean) AS ocean
FROM raw_dim_area;

DROP TABLE IF EXISTS dim_environment;
CREATE TABLE dim_environment STORED AS ORC AS
SELECT TRIM(environment_id) AS environment_id, TRIM(environment_name) AS environment_name
FROM raw_dim_environment;

DROP TABLE IF EXISTS dim_measure;
CREATE TABLE dim_measure STORED AS ORC AS
SELECT TRIM(measure_id) AS measure_id, TRIM(measure_name) AS measure_name, TRIM(short_name) AS short_name,
       CAST(multiplier AS INT) AS multiplier, TRIM(unit) AS unit,
       TRIM(measure_description) AS measure_description, TRIM(sws_unit) AS sws_unit
FROM raw_dim_measure;

DROP TABLE IF EXISTS dim_species;
CREATE TABLE dim_species STORED AS ORC AS
SELECT TRIM(species_id) AS species_id, NULLIF(TRIM(species_name), '') AS species_name,
       NULLIF(TRIM(scientific_name), '') AS scientific_name, NULLIF(TRIM(isscaap_group), '') AS isscaap_group,
       NULLIF(TRIM(major_group), '') AS major_group, NULLIF(TRIM(cpc_class), '') AS cpc_class,
       NULLIF(TRIM(cpc_group), '') AS cpc_group, NULLIF(TRIM(yearbook_group), '') AS yearbook_group,
       NULLIF(TRIM(author), '') AS author, NULLIF(TRIM(taxonomic_code), '') AS taxonomic_code
FROM raw_dim_species;

DROP TABLE IF EXISTS dim_status;
CREATE TABLE dim_status STORED AS ORC AS
SELECT TRIM(status_id) AS status_id, TRIM(status_name) AS status_name, TRIM(status_description) AS status_description
FROM raw_dim_status;

-- --------------------------------------------------------------------- facts
-- Production in tonnes live weight (the only measure present in the data: Q_tlw)
DROP TABLE IF EXISTS fact_capture;
CREATE TABLE fact_capture (
  country_id INT, species_id STRING, area_id INT, environment_id STRING,
  measure_id STRING, tonnes_live_weight DOUBLE, status_id STRING
)
PARTITIONED BY (prod_year INT)
STORED AS ORC;

INSERT OVERWRITE TABLE fact_capture PARTITION (prod_year)
SELECT CAST(country_id AS INT), TRIM(species_id), CAST(area_id AS INT), TRIM(environment_id),
       TRIM(measure_id), CAST(`value` AS DOUBLE), TRIM(status_id), CAST(`year` AS INT)
FROM raw_fact_capture
WHERE `year` RLIKE '^[0-9]{4}$';

DROP TABLE IF EXISTS fact_aquaculture;
CREATE TABLE fact_aquaculture (
  country_id INT, species_id STRING, area_id INT, environment_id STRING,
  measure_id STRING, tonnes_live_weight DOUBLE, status_id STRING
)
PARTITIONED BY (prod_year INT)
STORED AS ORC;

INSERT OVERWRITE TABLE fact_aquaculture PARTITION (prod_year)
SELECT CAST(country_id AS INT), TRIM(species_id), CAST(area_id AS INT), TRIM(environment_id),
       TRIM(measure_id), CAST(`value` AS DOUBLE), TRIM(status_id), CAST(`year` AS INT)
FROM raw_fact_aquaculture
WHERE `year` RLIKE '^[0-9]{4}$';

-- ------------------------------------------------- ocean climate observations
DROP TABLE IF EXISTS ocean_climate;
CREATE TABLE ocean_climate STORED AS ORC AS
SELECT CAST(`date` AS DATE)                      AS obs_date,
       YEAR(CAST(`date` AS DATE))                AS obs_year,
       MONTH(CAST(`date` AS DATE))               AS obs_month,
       TRIM(`location`)                          AS location_name,
       CAST(latitude AS DOUBLE)                  AS latitude,
       CAST(longitude AS DOUBLE)                 AS longitude,
       CAST(sst_c AS DOUBLE)                     AS sst_c,
       CAST(ph_level AS DOUBLE)                  AS ph_level,
       CASE WHEN TRIM(bleaching_severity) = 'Unkown' THEN 'Unknown'
            ELSE NULLIF(TRIM(bleaching_severity), '') END AS bleaching_severity,
       CAST(species_observed AS INT)             AS species_observed,
       (LOWER(TRIM(marine_heatwave)) = 'true')   AS marine_heatwave
FROM raw_ocean_climate;

-- ------------------------------------------------ coral monitoring (Palk Bay)
DROP TABLE IF EXISTS coral_monitoring;
CREATE TABLE coral_monitoring STORED AS ORC AS
SELECT CAST(`year` AS INT) AS obs_year, CAST(`month` AS INT) AS obs_month, CAST(`day` AS INT) AS obs_day,
       TRIM(site_name) AS site_name,
       CAST(latitude AS DOUBLE) AS latitude, CAST(longitude AS DOUBLE) AS longitude,
       CAST(temperature_celsius AS DOUBLE) AS temperature_c,
       CAST(ssta AS DOUBLE) AS ssta,
       CAST(dhw_stress AS DOUBLE) AS dhw_stress,
       CAST(hotspot AS DOUBLE) AS hotspot,
       CAST(oni_index AS DOUBLE) AS oni_index,
       TRIM(enso_phase) AS enso_phase,
       CAST(chlorophyll_a_mg_m3 AS DOUBLE) AS chlorophyll_a_mg_m3,
       CAST(bleaching_percent AS DOUBLE) AS bleaching_percent,
       TRIM(damage_state) AS damage_state,
       CAST(salinity AS DOUBLE) AS salinity,
       CAST(dissolved_o2 AS DOUBLE) AS dissolved_o2,
       CAST(ph AS DOUBLE) AS ph,
       CAST(nitrate AS DOUBLE) AS nitrate,
       CAST(depth_m AS DOUBLE) AS depth_m,
       CAST(distance_to_shore_km AS DOUBLE) AS distance_to_shore_km,
       CAST(ndvi AS DOUBLE) AS ndvi, CAST(ndwi AS DOUBLE) AS ndwi,
       CAST(turbidity_ntu AS DOUBLE) AS turbidity_ntu
FROM raw_coral;

-- ------------------------------------------------------------ marine economy
-- data_value units depend on `units` + `magnitude`: Dollars/Thousands = USD thousand,
-- Proportion = percentage points, Number = people.
DROP TABLE IF EXISTS marine_economy;
CREATE TABLE marine_economy STORED AS ORC AS
SELECT CAST(`year` AS INT) AS obs_year, TRIM(category) AS category, TRIM(variable) AS variable,
       TRIM(units) AS units, TRIM(magnitude) AS magnitude, TRIM(source) AS source,
       CAST(data_value AS DOUBLE) AS data_value, TRIM(flag) AS flag
FROM raw_economy;

-- -------------------------------------------- Southern Ocean plankton / bacteria
DROP TABLE IF EXISTS plankton_profile;
CREATE TABLE plankton_profile STORED AS ORC AS
SELECT CAST(start_latitude AS DOUBLE) AS start_latitude, CAST(start_longitude AS DOUBLE) AS start_longitude,
       CAST(end_latitude AS DOUBLE) AS end_latitude, CAST(end_longitude AS DOUBLE) AS end_longitude,
       CAST(transect_number AS INT) AS transect_number, TRIM(ctd_flow_file) AS ctd_flow_file,
       CAST(depth_m AS DOUBLE) AS depth_m,
       CAST(total_bacteria_ml AS DOUBLE) AS total_bacteria_ml,
       CAST(active_bacteria_ml AS DOUBLE) AS active_bacteria_ml,
       CAST(dead_bacteria_ml AS DOUBLE) AS dead_bacteria_ml,
       CAST(protozoa_ml AS DOUBLE) AS protozoa_ml,
       CAST(phytoplankton_ml AS DOUBLE) AS phytoplankton_ml,
       CAST(integrated_phytoplankton_ml AS DOUBLE) AS integrated_phytoplankton_ml
FROM raw_chlorophyll;

-- ------------------------------------------- CalCOFI-style oceanographic casts
DROP TABLE IF EXISTS ocean_casts;
CREATE TABLE ocean_casts STORED AS ORC AS
SELECT CAST(cst_cnt AS INT) AS cast_count, TRIM(cruise_id) AS cruise_id, TRIM(cast_id) AS cast_id,
       TRIM(sta_id) AS station_id, CAST(quarter AS INT) AS quarter,
       CAST(FROM_UNIXTIME(UNIX_TIMESTAMP(`date`, 'MM/dd/yyyy')) AS DATE) AS obs_date,
       CAST(`year` AS INT) AS obs_year, CAST(`month` AS INT) AS obs_month,
       CAST(lat_dec AS DOUBLE) AS latitude, CAST(lon_dec AS DOUBLE) AS longitude,
       CAST(bottom_d AS DOUBLE) AS bottom_depth_m,
       NULLIF(TRIM(ship_name), '') AS ship_name, NULLIF(TRIM(data_type), '') AS data_type,
       CAST(rpt_line AS DOUBLE) AS line_no, CAST(rpt_sta AS DOUBLE) AS station_no,
       CAST(wind_dir AS INT) AS wind_dir, CAST(wind_spd AS INT) AS wind_spd,
       CAST(wea AS INT) AS weather_code, NULLIF(TRIM(sta_code), '') AS station_code,
       CAST(julian_day AS INT) AS julian_day, TRIM(`time`) AS obs_time
FROM raw_cast;

-- ------------------------------------------------------------ plastic pollution
DROP TABLE IF EXISTS plastic_production_global;
CREATE TABLE plastic_production_global STORED AS ORC AS
SELECT CAST(`year` AS INT) AS obs_year,
       CAST(global_plastics_production_million_tonnes AS DOUBLE) AS production_million_tonnes
FROM raw_global_plastics_production;

-- One row per country (2010 snapshot): mismanaged share + per-capita waste + GDP/population.
DROP TABLE IF EXISTS plastic_country_2010;
CREATE TABLE plastic_country_2010 STORED AS ORC AS
SELECT TRIM(m.code)   AS iso3,
       TRIM(m.entity) AS country_name,
       CAST(m.`year` AS INT) AS obs_year,
       CAST(m.mismanaged_waste_pct_global_total AS DOUBLE)       AS mismanaged_pct_of_global,
       CAST(w.per_capita_plastic_waste_kg_person_day AS DOUBLE)  AS plastic_waste_kg_pp_day,
       CAST(c.per_capita_mismanaged_plastic_waste AS DOUBLE)     AS mismanaged_kg_pp_day,
       CAST(c.gdp_per_capita_ppp_constant_2011_international AS DOUBLE) AS gdp_per_capita_ppp,
       CAST(c.total_population_gapminder_hyde_un AS BIGINT)      AS population
FROM raw_mismanaged_waste_global m
LEFT JOIN raw_plastic_waste_per_capita w ON TRIM(w.code) = TRIM(m.code)
LEFT JOIN raw_per_capita_mismanaged_plastic c ON TRIM(c.code) = TRIM(m.code);

-- Gather statistics so the optimiser plans joins well
ANALYZE TABLE fact_capture PARTITION (prod_year) COMPUTE STATISTICS;
ANALYZE TABLE fact_aquaculture PARTITION (prod_year) COMPUTE STATISTICS;
