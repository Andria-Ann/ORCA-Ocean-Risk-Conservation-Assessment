-- =============================================================================
-- ORCA | Hive layer 1: RAW (landing) tables
-- Owner: Siva Pournami PB (Hive)
--
-- One EXTERNAL table per source sheet in Datas.xlsx, reading the CSV files that
-- scripts/load_to_hdfs.sh puts in /user/orca/raw/<table>/ .
--   * OpenCSVSerde reads quoted text with commas (species names, descriptions)
--   * OpenCSVSerde exposes every column as STRING, so all typing/cleaning happens
--     in 02_clean_tables.hql (raw data is never modified)
--   * skip.header.line.count drops the CSV header row
-- Column names are back-ticked: date / time / year / month / value / location are
-- keywords or built-in function names in Hive.
-- Run:  hive -f hive/01_raw_tables.hql      (or beeline -u <jdbc-url> -f ...)
-- =============================================================================

USE orca;

DROP TABLE IF EXISTS raw_dim_country;
CREATE EXTERNAL TABLE raw_dim_country (
  `country_id` STRING,
  `country_name` STRING,
  `iso2` STRING,
  `iso3` STRING,
  `continent` STRING,
  `geo_region` STRING,
  `economic_class` STRING,
  `official_name` STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ',', 'quoteChar' = '"', 'escapeChar' = '\\')
STORED AS TEXTFILE
LOCATION '/user/orca/raw/dim_country'
TBLPROPERTIES ('skip.header.line.count' = '1');

DROP TABLE IF EXISTS raw_dim_area;
CREATE EXTERNAL TABLE raw_dim_area (
  `area_id` STRING,
  `area_name` STRING,
  `inland_marine` STRING,
  `fa_region` STRING,
  `ocean` STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ',', 'quoteChar' = '"', 'escapeChar' = '\\')
STORED AS TEXTFILE
LOCATION '/user/orca/raw/dim_area'
TBLPROPERTIES ('skip.header.line.count' = '1');

DROP TABLE IF EXISTS raw_dim_environment;
CREATE EXTERNAL TABLE raw_dim_environment (
  `environment_id` STRING,
  `environment_name` STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ',', 'quoteChar' = '"', 'escapeChar' = '\\')
STORED AS TEXTFILE
LOCATION '/user/orca/raw/dim_environment'
TBLPROPERTIES ('skip.header.line.count' = '1');

DROP TABLE IF EXISTS raw_dim_measure;
CREATE EXTERNAL TABLE raw_dim_measure (
  `measure_id` STRING,
  `measure_name` STRING,
  `short_name` STRING,
  `multiplier` STRING,
  `unit` STRING,
  `measure_description` STRING,
  `sws_unit` STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ',', 'quoteChar' = '"', 'escapeChar' = '\\')
STORED AS TEXTFILE
LOCATION '/user/orca/raw/dim_measure'
TBLPROPERTIES ('skip.header.line.count' = '1');

DROP TABLE IF EXISTS raw_dim_species;
CREATE EXTERNAL TABLE raw_dim_species (
  `species_id` STRING,
  `species_name` STRING,
  `scientific_name` STRING,
  `isscaap_group` STRING,
  `major_group` STRING,
  `cpc_class` STRING,
  `cpc_group` STRING,
  `yearbook_group` STRING,
  `author` STRING,
  `taxonomic_code` STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ',', 'quoteChar' = '"', 'escapeChar' = '\\')
STORED AS TEXTFILE
LOCATION '/user/orca/raw/dim_species'
TBLPROPERTIES ('skip.header.line.count' = '1');

DROP TABLE IF EXISTS raw_dim_status;
CREATE EXTERNAL TABLE raw_dim_status (
  `status_id` STRING,
  `status_name` STRING,
  `status_description` STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ',', 'quoteChar' = '"', 'escapeChar' = '\\')
STORED AS TEXTFILE
LOCATION '/user/orca/raw/dim_status'
TBLPROPERTIES ('skip.header.line.count' = '1');

DROP TABLE IF EXISTS raw_fact_capture;
CREATE EXTERNAL TABLE raw_fact_capture (
  `country_id` STRING,
  `species_id` STRING,
  `area_id` STRING,
  `environment_id` STRING,
  `measure_id` STRING,
  `year` STRING,
  `value` STRING,
  `status_id` STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ',', 'quoteChar' = '"', 'escapeChar' = '\\')
STORED AS TEXTFILE
LOCATION '/user/orca/raw/fact_capture'
TBLPROPERTIES ('skip.header.line.count' = '1');

DROP TABLE IF EXISTS raw_fact_aquaculture;
CREATE EXTERNAL TABLE raw_fact_aquaculture (
  `country_id` STRING,
  `species_id` STRING,
  `area_id` STRING,
  `environment_id` STRING,
  `measure_id` STRING,
  `year` STRING,
  `value` STRING,
  `status_id` STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ',', 'quoteChar' = '"', 'escapeChar' = '\\')
STORED AS TEXTFILE
LOCATION '/user/orca/raw/fact_aquaculture'
TBLPROPERTIES ('skip.header.line.count' = '1');

DROP TABLE IF EXISTS raw_ocean_climate;
CREATE EXTERNAL TABLE raw_ocean_climate (
  `date` STRING,
  `location` STRING,
  `latitude` STRING,
  `longitude` STRING,
  `sst_c` STRING,
  `ph_level` STRING,
  `bleaching_severity` STRING,
  `species_observed` STRING,
  `marine_heatwave` STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ',', 'quoteChar' = '"', 'escapeChar' = '\\')
STORED AS TEXTFILE
LOCATION '/user/orca/raw/ocean_climate'
TBLPROPERTIES ('skip.header.line.count' = '1');

DROP TABLE IF EXISTS raw_coral;
CREATE EXTERNAL TABLE raw_coral (
  `year` STRING,
  `month` STRING,
  `day` STRING,
  `site_name` STRING,
  `latitude` STRING,
  `longitude` STRING,
  `temperature_kelvin` STRING,
  `temperature_celsius` STRING,
  `ssta` STRING,
  `dhw_stress` STRING,
  `hotspot` STRING,
  `oni_index` STRING,
  `enso_phase` STRING,
  `chlorophyll_a_mg_m3` STRING,
  `bleaching_percent` STRING,
  `damage_state` STRING,
  `salinity` STRING,
  `dissolved_o2` STRING,
  `ph` STRING,
  `nitrate` STRING,
  `depth_m` STRING,
  `distance_to_shore_km` STRING,
  `ndvi` STRING,
  `ndwi` STRING,
  `turbidity_ntu` STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ',', 'quoteChar' = '"', 'escapeChar' = '\\')
STORED AS TEXTFILE
LOCATION '/user/orca/raw/coral'
TBLPROPERTIES ('skip.header.line.count' = '1');

DROP TABLE IF EXISTS raw_economy;
CREATE EXTERNAL TABLE raw_economy (
  `year` STRING,
  `category` STRING,
  `variable` STRING,
  `units` STRING,
  `magnitude` STRING,
  `source` STRING,
  `data_value` STRING,
  `flag` STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ',', 'quoteChar' = '"', 'escapeChar' = '\\')
STORED AS TEXTFILE
LOCATION '/user/orca/raw/economy'
TBLPROPERTIES ('skip.header.line.count' = '1');

DROP TABLE IF EXISTS raw_chlorophyll;
CREATE EXTERNAL TABLE raw_chlorophyll (
  `start_latitude` STRING,
  `start_longitude` STRING,
  `end_latitude` STRING,
  `end_longitude` STRING,
  `transect_number` STRING,
  `ctd_flow_file` STRING,
  `depth_m` STRING,
  `total_bacteria_ml` STRING,
  `active_bacteria_ml` STRING,
  `dead_bacteria_ml` STRING,
  `protozoa_ml` STRING,
  `phytoplankton_ml` STRING,
  `integrated_phytoplankton_ml` STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ',', 'quoteChar' = '"', 'escapeChar' = '\\')
STORED AS TEXTFILE
LOCATION '/user/orca/raw/chlorophyll'
TBLPROPERTIES ('skip.header.line.count' = '1');

DROP TABLE IF EXISTS raw_cast;
CREATE EXTERNAL TABLE raw_cast (
  `cst_cnt` STRING,
  `cruise_id` STRING,
  `cruise` STRING,
  `cruz_sta` STRING,
  `dbsta_id` STRING,
  `cast_id` STRING,
  `sta_id` STRING,
  `quarter` STRING,
  `sta_code` STRING,
  `distance` STRING,
  `date` STRING,
  `year` STRING,
  `month` STRING,
  `julian_date` STRING,
  `julian_day` STRING,
  `time` STRING,
  `lat_dec` STRING,
  `lat_deg` STRING,
  `lat_min` STRING,
  `lat_hem` STRING,
  `lon_dec` STRING,
  `lon_deg` STRING,
  `lon_min` STRING,
  `lon_hem` STRING,
  `rpt_line` STRING,
  `st_line` STRING,
  `ac_line` STRING,
  `rpt_sta` STRING,
  `st_station` STRING,
  `ac_sta` STRING,
  `bottom_d` STRING,
  `secchi` STRING,
  `forelu` STRING,
  `ship_name` STRING,
  `ship_code` STRING,
  `data_type` STRING,
  `order_occ` STRING,
  `event_num` STRING,
  `cruz_leg` STRING,
  `orig_sta_id` STRING,
  `data_or` STRING,
  `cruz_num` STRING,
  `intchl` STRING,
  `intc14` STRING,
  `inc_str` STRING,
  `inc_end` STRING,
  `pst_lan` STRING,
  `civil_t` STRING,
  `timezone` STRING,
  `wave_dir` STRING,
  `wave_ht` STRING,
  `wave_prd` STRING,
  `wind_dir` STRING,
  `wind_spd` STRING,
  `barometer` STRING,
  `dry_t` STRING,
  `wet_t` STRING,
  `wea` STRING,
  `cloud_typ` STRING,
  `cloud_amt` STRING,
  `visibility` STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ',', 'quoteChar' = '"', 'escapeChar' = '\\')
STORED AS TEXTFILE
LOCATION '/user/orca/raw/cast'
TBLPROPERTIES ('skip.header.line.count' = '1');

DROP TABLE IF EXISTS raw_global_plastics_production;
CREATE EXTERNAL TABLE raw_global_plastics_production (
  `entity` STRING,
  `code` STRING,
  `year` STRING,
  `global_plastics_production_million_tonnes` STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ',', 'quoteChar' = '"', 'escapeChar' = '\\')
STORED AS TEXTFILE
LOCATION '/user/orca/raw/global_plastics_production'
TBLPROPERTIES ('skip.header.line.count' = '1');

DROP TABLE IF EXISTS raw_mismanaged_waste_global;
CREATE EXTERNAL TABLE raw_mismanaged_waste_global (
  `entity` STRING,
  `code` STRING,
  `year` STRING,
  `mismanaged_waste_pct_global_total` STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ',', 'quoteChar' = '"', 'escapeChar' = '\\')
STORED AS TEXTFILE
LOCATION '/user/orca/raw/mismanaged_waste_global'
TBLPROPERTIES ('skip.header.line.count' = '1');

DROP TABLE IF EXISTS raw_per_capita_mismanaged_plastic;
CREATE EXTERNAL TABLE raw_per_capita_mismanaged_plastic (
  `entity` STRING,
  `code` STRING,
  `year` STRING,
  `per_capita_mismanaged_plastic_waste` STRING,
  `gdp_per_capita_ppp_constant_2011_international` STRING,
  `total_population_gapminder_hyde_un` STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ',', 'quoteChar' = '"', 'escapeChar' = '\\')
STORED AS TEXTFILE
LOCATION '/user/orca/raw/per_capita_mismanaged_plastic'
TBLPROPERTIES ('skip.header.line.count' = '1');

DROP TABLE IF EXISTS raw_per_capita_plastic_waste_gdp;
CREATE EXTERNAL TABLE raw_per_capita_plastic_waste_gdp (
  `entity` STRING,
  `code` STRING,
  `year` STRING,
  `per_capita_plastic_waste_kg_person_day` STRING,
  `gdp_per_capita_ppp_constant_2011_international` STRING,
  `total_population_gapminder_hyde_un` STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ',', 'quoteChar' = '"', 'escapeChar' = '\\')
STORED AS TEXTFILE
LOCATION '/user/orca/raw/per_capita_plastic_waste_gdp'
TBLPROPERTIES ('skip.header.line.count' = '1');

DROP TABLE IF EXISTS raw_plastic_waste_per_capita;
CREATE EXTERNAL TABLE raw_plastic_waste_per_capita (
  `entity` STRING,
  `code` STRING,
  `year` STRING,
  `per_capita_plastic_waste_kg_person_day` STRING
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('separatorChar' = ',', 'quoteChar' = '"', 'escapeChar' = '\\')
STORED AS TEXTFILE
LOCATION '/user/orca/raw/plastic_waste_per_capita'
TBLPROPERTIES ('skip.header.line.count' = '1');
