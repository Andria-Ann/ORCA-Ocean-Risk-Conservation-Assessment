-- =============================================================================
-- ORCA | Hive layer 3: reusable VIEWS
-- Owner: Siva Pournami PB (Hive)
-- =============================================================================

USE orca;

-- Denormalised fish production (capture + aquaculture) with all dimension attributes.
-- LEFT JOINs on purpose: ~25% of fact rows have a species_id missing from dim_species and
-- some area_ids (inland areas) are not in dim_area. Inner joins would silently drop them.
CREATE OR REPLACE VIEW vw_fish_production AS
SELECT u.production_type,
       u.prod_year,
       u.country_id,
       c.country_name, c.iso3, c.continent, c.geo_region, c.economic_class,
       u.species_id,
       s.species_name, s.scientific_name, s.isscaap_group, s.major_group,
       u.area_id,
       a.area_name, a.ocean AS ocean_name, a.fa_region,
       u.environment_id,
       e.environment_name,
       u.status_id,
       u.tonnes_live_weight
FROM (
  SELECT 'capture' AS production_type, prod_year, country_id, species_id, area_id,
         environment_id, status_id, tonnes_live_weight
  FROM fact_capture
  UNION ALL
  SELECT 'aquaculture' AS production_type, prod_year, country_id, species_id, area_id,
         environment_id, status_id, tonnes_live_weight
  FROM fact_aquaculture
) u
LEFT JOIN dim_country     c ON u.country_id     = c.country_id
LEFT JOIN dim_species     s ON u.species_id     = s.species_id
LEFT JOIN dim_area        a ON u.area_id        = a.area_id
LEFT JOIN dim_environment e ON u.environment_id = e.environment_id;

-- Marine wild-capture only, by FAO area and year (the base for stock-decline analysis)
CREATE OR REPLACE VIEW vw_marine_capture_area_year AS
SELECT f.prod_year, f.area_id, a.area_name, a.ocean AS ocean_name,
       SUM(f.tonnes_live_weight) AS tonnes
FROM fact_capture f
JOIN dim_area a ON f.area_id = a.area_id          -- inner join: marine FAO areas only
WHERE f.environment_id = 'MA'
GROUP BY f.prod_year, f.area_id, a.area_name, a.ocean;

-- Wide, typed marine-economy table: one row per year x sector
CREATE OR REPLACE VIEW vw_marine_economy_wide AS
SELECT obs_year, category,
       MAX(CASE WHEN variable = 'GDP'                                 THEN data_value END) AS gdp_usd_thousand,
       MAX(CASE WHEN variable = 'Gross earnings'                      THEN data_value END) AS gross_earnings_usd_thousand,
       MAX(CASE WHEN variable = 'Mean earnings'                       THEN data_value END) AS mean_earnings_usd_thousand,
       MAX(CASE WHEN variable = 'Wage and salary earners'             THEN data_value END) AS employees,
       MAX(CASE WHEN variable = 'Contribution to total GDP'           THEN data_value END) AS pct_of_total_gdp,
       MAX(CASE WHEN variable = 'Contribution to marine economy GDP'  THEN data_value END) AS pct_of_marine_gdp
FROM marine_economy
GROUP BY obs_year, category;
