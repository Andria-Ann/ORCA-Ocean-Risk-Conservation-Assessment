-- =============================================================================
-- ORCA | Hive setup: database and session settings
-- Owner: Siva Pournami PB (Hive)
-- Run first:  hive -f hive/00_setup.hql
-- =============================================================================

CREATE DATABASE IF NOT EXISTS orca
COMMENT 'ORCA - Ocean Risk & Conservation Assessment (marine ecosystem risk data warehouse)'
LOCATION '/user/hive/warehouse/orca.db';

USE orca;

-- Settings used by the load / mart scripts (put them at the top of each script or in ~/.hiverc)
SET hive.exec.dynamic.partition = true;
SET hive.exec.dynamic.partition.mode = nonstrict;
SET hive.exec.max.dynamic.partitions = 1000;
SET hive.exec.max.dynamic.partitions.pernode = 1000;
SET hive.cli.print.header = true;
