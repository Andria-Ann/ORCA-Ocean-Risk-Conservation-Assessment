"""Local logic check for the ORCA Hive SQL - NO Hadoop/Hive needed.

Loads the CSVs into an in-memory SQLite database that mimics the *clean* layer
(02_clean_tables.hql), then runs 03_views.hql, 04_risk_marts.hql and every query in
queries/ with small syntax shims (STORED AS ORC / USE / SET removed, CORR added).
It proves the joins, windows and arithmetic work and that nothing returns an error.
It does NOT replace a run on a real Hive (02_clean_tables.hql and the raw tables
are not exercised).

Usage:  python3 hive/tests/local_sqlite_check.py data/csv [rows_to_print_per_query]
Needs:  pandas, numpy
"""
import sqlite3, pandas as pd, numpy as np, re, glob, math, sys
import os
D = (sys.argv[1] if len(sys.argv) > 1 else 'data/csv').rstrip('/') + '/'
H = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..') + '/'
r=lambda n: pd.read_csv(D+n+'.csv',low_memory=False)
con=sqlite3.connect(':memory:')
class Corr:
    def __init__(s): s.x=[];s.y=[]
    def step(s,a,b):
        if a is not None and b is not None: s.x.append(a);s.y.append(b)
    def finalize(s):
        if len(s.x)<2: return None
        v=np.corrcoef(s.x,s.y)[0,1]; return None if math.isnan(v) else float(v)
con.create_aggregate('corr',2,Corr)
def put(df,name): df.to_sql(name,con,index=False)
for t in ['dim_country','dim_area','dim_environment','dim_measure','dim_species','dim_status']: put(r(t),t)
for src,dst in [('fact_capture','fact_capture'),('fact_aquaculture','fact_aquaculture')]:
    d=r(src).rename(columns={'value':'tonnes_live_weight','year':'prod_year'}); d['tonnes_live_weight']=d.tonnes_live_weight.astype(float); put(d,dst)
oc=r('ocean_climate'); oc['obs_date']=oc['date']; oc['obs_year']=oc.date.str[:4].astype(int); oc['obs_month']=oc.date.str[5:7].astype(int)
oc['marine_heatwave']=oc.marine_heatwave.astype(str).str.lower().eq('true').astype(int)
oc['bleaching_severity']=oc.bleaching_severity.replace('Unkown','Unknown')
put(oc.rename(columns={'location':'location_name'}).drop(columns='date'),'ocean_climate')
c=r('coral_cleaned').rename(columns={'year':'obs_year','month':'obs_month','day':'obs_day','temperature_celsius':'temperature_c'}).drop(columns='temperature_kelvin'); put(c,'coral_monitoring')
e=r('economy_cleaned').rename(columns={'year':'obs_year'}); put(e,'marine_economy')
put(r('chlorophyll_cleaned'),'plankton_profile')
k=r('cast_cleaned').rename(columns={'year':'obs_year','month':'obs_month','lat_dec':'latitude','lon_dec':'longitude','bottom_d':'bottom_depth_m','sta_id':'station_id'}); put(k[['cruise_id','station_id','quarter','obs_year','obs_month','latitude','longitude','bottom_depth_m','ship_name','data_type']],'ocean_casts')
g=r('global_plastics_production'); put(g.rename(columns={'year':'obs_year','global_plastics_production_million_tonnes':'production_million_tonnes'})[['obs_year','production_million_tonnes']],'plastic_production_global')
m=r('mismanaged_waste_global');w=r('plastic_waste_per_capita');pc=r('per_capita_mismanaged_plastic')
p=m.merge(w[['code','per_capita_plastic_waste_kg_person_day']],on='code',how='left').merge(pc[['code','per_capita_mismanaged_plastic_waste','gdp_per_capita_ppp_constant_2011_international','total_population_gapminder_hyde_un']],on='code',how='left')
p=p.rename(columns={'code':'iso3','entity':'country_name','year':'obs_year','mismanaged_waste_pct_global_total':'mismanaged_pct_of_global','per_capita_plastic_waste_kg_person_day':'plastic_waste_kg_pp_day','per_capita_mismanaged_plastic_waste':'mismanaged_kg_pp_day','gdp_per_capita_ppp_constant_2011_international':'gdp_per_capita_ppp','total_population_gapminder_hyde_un':'population'})
put(p,'plastic_country_2010')

def clean(sql):
    sql=re.sub(r'--[^\n]*','',sql)
    out=[]
    for st in sql.split(';'):
        st=st.strip()
        if not st or re.match(r'(USE|SET|ANALYZE)\b',st,re.I): continue
        st=re.sub(r'STORED AS ORC\s*','',st)
        st=st.replace('CREATE OR REPLACE VIEW','CREATE VIEW')
        out.append(st)
    return out
def run(path,show=0):
    errs=0
    for st in clean(open(path).read()):
        m=re.match(r'CREATE VIEW (\w+)',st)
        if m: con.execute(f'DROP VIEW IF EXISTS {m.group(1)}')
        m=re.match(r'DROP TABLE IF EXISTS (\w+)',st)
        try:
            cur=con.execute(st)
            if st.upper().startswith('SELECT') or st.upper().startswith('WITH'):
                rows=cur.fetchall()
                cols=[d[0] for d in cur.description]
                print(f'  OK {len(rows):>4} rows | {st[:70]!r}')
                if show: print(pd.DataFrame(rows,columns=cols).head(show).to_string())
        except Exception as ex:
            errs+=1; print('  ERR',ex,'\n    ',st[:200].replace('\n',' '))
    return errs
tot=0
for f in ['03_views.hql','04_risk_marts.hql']+sorted(glob.glob(H+'queries/q*.hql')):
    f=f if f.startswith('/') else H+f
    print('==',f.split('/')[-1]); tot+=run(f,show=int(sys.argv[2]) if len(sys.argv)>2 else 0)
print('TOTAL ERRORS',tot)
