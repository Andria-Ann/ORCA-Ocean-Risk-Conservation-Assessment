-- ORCA | Q08 Plankton / bacteria profiles (Southern Ocean) and oceanographic casts (California Current)
USE orca;

-- 1. Microbial community by depth band
SELECT CASE WHEN depth_m < 25 THEN '0-25 m' WHEN depth_m < 50 THEN '25-50 m'
            WHEN depth_m < 100 THEN '50-100 m' ELSE '100 m+' END AS depth_band,
       COUNT(*) AS samples,
       ROUND(AVG(total_bacteria_ml), 0)  AS avg_total_bacteria,
       ROUND(AVG(active_bacteria_ml), 0) AS avg_active_bacteria,
       ROUND(100.0 * AVG(active_bacteria_ml / NULLIF(total_bacteria_ml, 0)), 1) AS pct_active,
       ROUND(AVG(phytoplankton_ml), 0)   AS avg_phytoplankton
FROM plankton_profile
GROUP BY CASE WHEN depth_m < 25 THEN '0-25 m' WHEN depth_m < 50 THEN '25-50 m'
              WHEN depth_m < 100 THEN '50-100 m' ELSE '100 m+' END
ORDER BY depth_band;

-- 2. Per transect: bacteria and phytoplankton totals (find the biologically richest transects)
SELECT transect_number, COUNT(*) AS samples,
       ROUND(AVG(total_bacteria_ml), 0) AS avg_bacteria,
       ROUND(AVG(phytoplankton_ml), 0)  AS avg_phyto,
       ROUND(100.0 * AVG(dead_bacteria_ml / NULLIF(total_bacteria_ml, 0)), 1) AS pct_dead_bacteria
FROM plankton_profile
GROUP BY transect_number
ORDER BY avg_bacteria DESC;

-- 3. Sampling effort of the cast archive per decade (coverage of the long-term record)
SELECT CAST(FLOOR(obs_year / 10) * 10 AS INT) AS decade, COUNT(*) AS casts,
       COUNT(DISTINCT cruise_id) AS cruises, COUNT(DISTINCT station_id) AS stations
FROM ocean_casts
GROUP BY CAST(FLOOR(obs_year / 10) * 10 AS INT)
ORDER BY decade;

-- 4. Seasonal coverage: casts by quarter
SELECT quarter, COUNT(*) AS casts
FROM ocean_casts
GROUP BY quarter
ORDER BY quarter;

-- 5. Spatial grid (1 degree cells): where the archive is densest / sparsest
SELECT FLOOR(latitude) AS lat_cell, FLOOR(longitude) AS lon_cell, COUNT(*) AS casts
FROM ocean_casts
GROUP BY FLOOR(latitude), FLOOR(longitude)
ORDER BY casts DESC
LIMIT 20;

-- 6. Research vessels in the archive and their active years
SELECT ship_name, COUNT(*) AS casts, MIN(obs_year) AS first_year, MAX(obs_year) AS last_year
FROM ocean_casts
WHERE ship_name IS NOT NULL
GROUP BY ship_name
ORDER BY casts DESC
LIMIT 15;
