-- ORCA | Q05 Climate stress and coral bleaching
USE orca;

-- 1. Reef locations (ocean_climate): conditions and bleaching mix
SELECT location_name,
       COUNT(*) AS obs,
       ROUND(AVG(sst_c), 2) AS avg_sst,
       ROUND(AVG(ph_level), 3) AS avg_ph,
       SUM(CASE WHEN bleaching_severity = 'High'    THEN 1 ELSE 0 END) AS high,
       SUM(CASE WHEN bleaching_severity = 'Medium'  THEN 1 ELSE 0 END) AS medium,
       SUM(CASE WHEN bleaching_severity = 'Low'     THEN 1 ELSE 0 END) AS low,
       SUM(CASE WHEN bleaching_severity = 'Unknown' THEN 1 ELSE 0 END) AS unknown,
       SUM(CASE WHEN marine_heatwave THEN 1 ELSE 0 END) AS heatwave_obs
FROM ocean_climate
GROUP BY location_name
ORDER BY avg_sst DESC;

-- 2. Do marine heatwaves coincide with worse bleaching? (known severities only)
SELECT CASE WHEN marine_heatwave THEN 'Heatwave' ELSE 'No heatwave' END AS condition_,
       bleaching_severity, COUNT(*) AS n,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (PARTITION BY marine_heatwave), 1) AS pct_within_condition
FROM ocean_climate
WHERE bleaching_severity <> 'Unknown'
GROUP BY marine_heatwave, bleaching_severity
ORDER BY condition_, bleaching_severity;

-- 3. SST bands vs bleaching severity
SELECT CASE WHEN sst_c < 27 THEN '<27C' WHEN sst_c < 28 THEN '27-28C'
            WHEN sst_c < 29 THEN '28-29C' WHEN sst_c < 30 THEN '29-30C' ELSE '30C+' END AS sst_band,
       COUNT(*) AS n,
       ROUND(100.0 * AVG(CASE WHEN bleaching_severity = 'High' THEN 1.0 ELSE 0.0 END), 1) AS pct_high_all,
       ROUND(AVG(ph_level), 3) AS avg_ph
FROM ocean_climate
GROUP BY CASE WHEN sst_c < 27 THEN '<27C' WHEN sst_c < 28 THEN '27-28C'
              WHEN sst_c < 29 THEN '28-29C' WHEN sst_c < 30 THEN '29-30C' ELSE '30C+' END
ORDER BY sst_band;

-- 4. Yearly trend per location: average SST and pH (ocean warming / acidification signal)
SELECT location_name, obs_year, COUNT(*) AS obs, ROUND(AVG(sst_c), 2) AS avg_sst, ROUND(AVG(ph_level), 3) AS avg_ph
FROM ocean_climate
GROUP BY location_name, obs_year
ORDER BY location_name, obs_year;

-- 5. Correlation of drivers with the species count (biodiversity signal)
SELECT ROUND(CORR(sst_c, species_observed), 3)       AS corr_sst_species,
       ROUND(CORR(ph_level, species_observed), 3)    AS corr_ph_species,
       ROUND(CORR(sst_c, ph_level), 3)               AS corr_sst_ph
FROM ocean_climate;

-- 6. Palk Bay coral sites: damage state by ENSO phase
SELECT enso_phase, damage_state, COUNT(*) AS n,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (PARTITION BY enso_phase), 1) AS pct_within_phase
FROM coral_monitoring
GROUP BY enso_phase, damage_state
ORDER BY enso_phase, damage_state;

-- 7. Coral heat-stress thresholds: DHW bands (NOAA: >=4 bleaching likely, >=8 severe) vs measured bleaching %
SELECT CASE WHEN dhw_stress < 1 THEN '0-1 none' WHEN dhw_stress < 4 THEN '1-4 watch'
            WHEN dhw_stress < 8 THEN '4-8 bleaching likely' ELSE '8+ severe' END AS dhw_band,
       COUNT(*) AS n,
       ROUND(AVG(bleaching_percent), 1) AS avg_bleaching_pct,
       ROUND(100.0 * AVG(CASE WHEN damage_state IN ('bleached', 'severe_bleach') THEN 1.0 ELSE 0.0 END), 1) AS pct_bleached_or_severe
FROM coral_monitoring
GROUP BY CASE WHEN dhw_stress < 1 THEN '0-1 none' WHEN dhw_stress < 4 THEN '1-4 watch'
              WHEN dhw_stress < 8 THEN '4-8 bleaching likely' ELSE '8+ severe' END
ORDER BY dhw_band;

-- 8. Worst years at the coral sites
SELECT obs_year, COUNT(*) AS obs, ROUND(AVG(temperature_c), 2) AS avg_temp, ROUND(AVG(dhw_stress), 2) AS avg_dhw,
       ROUND(AVG(bleaching_percent), 1) AS avg_bleaching_pct,
       ROUND(100.0 * AVG(CASE WHEN damage_state = 'severe_bleach' THEN 1.0 ELSE 0.0 END), 1) AS pct_severe
FROM coral_monitoring
GROUP BY obs_year
ORDER BY avg_bleaching_pct DESC
LIMIT 10;

-- 9. Drivers of bleaching at coral sites: correlations with bleaching_percent
SELECT ROUND(CORR(dhw_stress, bleaching_percent), 3)          AS corr_dhw,
       ROUND(CORR(temperature_c, bleaching_percent), 3)       AS corr_temp,
       ROUND(CORR(ssta, bleaching_percent), 3)                AS corr_ssta,
       ROUND(CORR(turbidity_ntu, bleaching_percent), 3)       AS corr_turbidity,
       ROUND(CORR(ph, bleaching_percent), 3)                  AS corr_ph,
       ROUND(CORR(chlorophyll_a_mg_m3, bleaching_percent), 3) AS corr_chl
FROM coral_monitoring;
