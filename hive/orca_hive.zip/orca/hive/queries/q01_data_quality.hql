-- ORCA | Q01 Data-quality audit (run this first; results go in docs/ as the data-quality note)
USE orca;

-- 1. Row counts of every clean table
SELECT 'fact_capture' AS tbl, COUNT(*) AS n FROM fact_capture
UNION ALL SELECT 'fact_aquaculture', COUNT(*) FROM fact_aquaculture
UNION ALL SELECT 'dim_country', COUNT(*) FROM dim_country
UNION ALL SELECT 'dim_species', COUNT(*) FROM dim_species
UNION ALL SELECT 'dim_area', COUNT(*) FROM dim_area
UNION ALL SELECT 'ocean_climate', COUNT(*) FROM ocean_climate
UNION ALL SELECT 'coral_monitoring', COUNT(*) FROM coral_monitoring
UNION ALL SELECT 'marine_economy', COUNT(*) FROM marine_economy
UNION ALL SELECT 'plankton_profile', COUNT(*) FROM plankton_profile
UNION ALL SELECT 'ocean_casts', COUNT(*) FROM ocean_casts
UNION ALL SELECT 'plastic_country_2010', COUNT(*) FROM plastic_country_2010
UNION ALL SELECT 'plastic_production_global', COUNT(*) FROM plastic_production_global;

-- 2. Are capture and aquaculture really different datasets?
--    In the supplied workbook both sheets are identical row-for-row -> expect rows_identical = rows_capture.
--    If so, the aquaculture sheet is a copy-paste of capture and must be re-exported from FAO FishStat.
SELECT COUNT(*) AS rows_capture,
       SUM(CASE WHEN a.country_id IS NOT NULL AND c.tonnes_live_weight = a.tonnes_live_weight THEN 1 ELSE 0 END) AS rows_identical
FROM fact_capture c
LEFT JOIN fact_aquaculture a
  ON  c.country_id = a.country_id AND c.species_id = a.species_id AND c.area_id = a.area_id
  AND c.environment_id = a.environment_id AND c.prod_year = a.prod_year;

-- 3. Orphan foreign keys in fact_capture (rows that would vanish with an INNER JOIN)
SELECT SUM(CASE WHEN c.country_id IS NULL THEN 1 ELSE 0 END)  AS orphan_country_rows,
       SUM(CASE WHEN s.species_id IS NULL THEN 1 ELSE 0 END)  AS orphan_species_rows,
       SUM(CASE WHEN a.area_id    IS NULL THEN 1 ELSE 0 END)  AS orphan_area_rows,
       COUNT(*)                                               AS total_rows
FROM fact_capture f
LEFT JOIN dim_country c ON f.country_id = c.country_id
LEFT JOIN dim_species s ON f.species_id = s.species_id
LEFT JOIN dim_area    a ON f.area_id    = a.area_id;

-- 4. Species ids used in facts but missing from dim_species (top offenders by tonnage)
SELECT f.species_id, COUNT(*) AS fact_rows, ROUND(SUM(f.tonnes_live_weight), 0) AS tonnes
FROM fact_capture f
LEFT JOIN dim_species s ON f.species_id = s.species_id
WHERE s.species_id IS NULL
GROUP BY f.species_id
ORDER BY tonnes DESC
LIMIT 20;

-- 5. Marine rows pointing at inland FAO areas (area_id 1-8 are inland-water areas, not in dim_area)
SELECT area_id, COUNT(*) AS marine_env_rows, ROUND(SUM(tonnes_live_weight), 0) AS tonnes
FROM fact_capture
WHERE environment_id = 'MA' AND area_id NOT IN (SELECT area_id FROM dim_area)
GROUP BY area_id
ORDER BY tonnes DESC;

-- 6. FAO status flags (A=official, I=imputed, N=not significant, E=estimated, Q=suppressed)
SELECT f.status_id, st.status_name, COUNT(*) AS n,
       ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct_rows,
       ROUND(100.0 * SUM(f.tonnes_live_weight) / SUM(SUM(f.tonnes_live_weight)) OVER (), 2) AS pct_tonnes
FROM fact_capture f
LEFT JOIN dim_status st ON f.status_id = st.status_id
GROUP BY f.status_id, st.status_name
ORDER BY n DESC;

-- 7. Zero-production rows (placeholders) by year range
SELECT MIN(prod_year) AS first_year, MAX(prod_year) AS last_year,
       SUM(CASE WHEN tonnes_live_weight = 0 THEN 1 ELSE 0 END) AS zero_rows,
       COUNT(*) AS all_rows
FROM fact_capture;

-- 8. ocean_climate: how much of the bleaching label is unknown?
SELECT bleaching_severity, COUNT(*) AS n, ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct
FROM ocean_climate
GROUP BY bleaching_severity
ORDER BY n DESC;

-- 9. Null audit for the numeric climate / coral columns
SELECT SUM(CASE WHEN sst_c IS NULL THEN 1 ELSE 0 END) AS null_sst,
       SUM(CASE WHEN ph_level IS NULL THEN 1 ELSE 0 END) AS null_ph,
       SUM(CASE WHEN latitude IS NULL OR longitude IS NULL THEN 1 ELSE 0 END) AS null_coords
FROM ocean_climate;

SELECT SUM(CASE WHEN bleaching_percent IS NULL THEN 1 ELSE 0 END) AS null_bleaching,
       SUM(CASE WHEN dhw_stress IS NULL THEN 1 ELSE 0 END)        AS null_dhw,
       SUM(CASE WHEN temperature_c IS NULL THEN 1 ELSE 0 END)     AS null_temp
FROM coral_monitoring;

-- 10. Plastic countries that did not match dim_country (these drop out of mart_country_exposure)
SELECT p.iso3, p.country_name, p.mismanaged_pct_of_global
FROM plastic_country_2010 p
LEFT JOIN dim_country c ON p.iso3 = c.iso3
WHERE c.country_id IS NULL
ORDER BY p.mismanaged_pct_of_global DESC;
