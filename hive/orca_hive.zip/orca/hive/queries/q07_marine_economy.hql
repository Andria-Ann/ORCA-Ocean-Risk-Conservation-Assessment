-- ORCA | Q07 Marine economy: how much value is exposed to ecosystem risk?
-- Units: GDP / earnings in USD thousand; employees = people; pct_* = percentage points
USE orca;

-- 1. Sector ranking by GDP in the latest year with data, with share of the marine economy
SELECT category, gdp_usd_thousand,
       ROUND(100.0 * gdp_usd_thousand / SUM(gdp_usd_thousand) OVER (), 1) AS pct_of_listed_gdp,
       employees, pct_of_total_gdp
FROM vw_marine_economy_wide
WHERE obs_year = 2021 AND category <> 'Total marine economy'
ORDER BY gdp_usd_thousand DESC;

-- 2. Year-by-year GDP growth per sector (from the mart)
SELECT category, obs_year, gdp_usd_thousand, gdp_yoy_pct
FROM mart_marine_economy_sector
WHERE category <> 'Total marine economy'
ORDER BY category, obs_year;

-- 3. Compound annual growth 2007 -> 2021 (or first-to-last available year) per sector
SELECT f.category,
       f.first_year, l.last_year,
       ROUND((POWER(l.gdp / f.gdp, 1.0 / (l.last_year - f.first_year)) - 1) * 100, 2) AS gdp_cagr_pct
FROM (SELECT category, MIN(obs_year) AS first_year FROM vw_marine_economy_wide WHERE gdp_usd_thousand > 0 GROUP BY category) fy
JOIN (SELECT w.category, w.obs_year AS first_year, w.gdp_usd_thousand AS gdp FROM vw_marine_economy_wide w) f
  ON f.category = fy.category AND f.first_year = fy.first_year
JOIN (SELECT category, MAX(obs_year) AS last_year FROM vw_marine_economy_wide WHERE gdp_usd_thousand > 0 GROUP BY category) ly
  ON ly.category = fy.category
JOIN (SELECT w.category, w.obs_year AS last_year, w.gdp_usd_thousand AS gdp FROM vw_marine_economy_wide w) l
  ON l.category = ly.category AND l.last_year = ly.last_year
WHERE f.category <> 'Total marine economy'
ORDER BY gdp_cagr_pct DESC;

-- 4. Reef/fishery-dependent value: fisheries + tourism combined, and their share of the marine economy
SELECT obs_year,
       SUM(CASE WHEN category IN ('Fisheries and aquaculture', 'Marine tourism and recreation') THEN gdp_usd_thousand END) AS ecosystem_dependent_gdp,
       SUM(CASE WHEN category = 'Total marine economy' THEN gdp_usd_thousand END)                                         AS total_marine_gdp,
       ROUND(100.0 * SUM(CASE WHEN category IN ('Fisheries and aquaculture', 'Marine tourism and recreation') THEN gdp_usd_thousand END)
             / NULLIF(SUM(CASE WHEN category = 'Total marine economy' THEN gdp_usd_thousand END), 0), 1)                  AS pct_of_marine_gdp
FROM vw_marine_economy_wide
GROUP BY obs_year
ORDER BY obs_year;

-- 5. Illustrative loss scenario: GDP at risk if ecosystem-dependent sectors fall 10 / 20 / 30 %
--    (scenario multipliers are assumptions for the dashboard "what-if" slider, not forecasts)
SELECT s.shock_pct,
       ROUND(d.ecosystem_gdp * s.shock_pct / 100.0, 0) AS gdp_at_risk_usd_thousand
FROM (SELECT SUM(gdp_usd_thousand) AS ecosystem_gdp
      FROM vw_marine_economy_wide
      WHERE obs_year = 2021 AND category IN ('Fisheries and aquaculture', 'Marine tourism and recreation')) d
CROSS JOIN (SELECT 10 AS shock_pct UNION ALL SELECT 20 UNION ALL SELECT 30) s
ORDER BY s.shock_pct;

-- 6. Jobs: sector employment and mean earnings, latest year
SELECT category, employees, mean_earnings_usd_thousand
FROM vw_marine_economy_wide
WHERE obs_year = 2021 AND employees IS NOT NULL
ORDER BY employees DESC;
