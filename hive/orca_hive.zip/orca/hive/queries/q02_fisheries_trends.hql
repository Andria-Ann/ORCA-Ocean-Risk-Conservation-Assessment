-- ORCA | Q02 Fisheries production trends (marine wild capture, tonnes live weight)
USE orca;

-- 1. Global marine capture by decade
SELECT CAST(FLOOR(prod_year / 10) * 10 AS INT) AS decade,
       ROUND(SUM(tonnes_live_weight) / 1e6, 2) AS million_tonnes,
       COUNT(DISTINCT country_id)              AS producing_countries
FROM fact_capture
WHERE environment_id = 'MA'
GROUP BY CAST(FLOOR(prod_year / 10) * 10 AS INT)
ORDER BY decade;

-- 2. Top 10 marine-capture countries in the latest year, with share of the world total
SELECT RANK() OVER (ORDER BY SUM(f.tonnes_live_weight) DESC) AS rnk,
       c.country_name, c.continent, c.economic_class,
       ROUND(SUM(f.tonnes_live_weight), 0) AS tonnes,
       ROUND(100.0 * SUM(f.tonnes_live_weight) / SUM(SUM(f.tonnes_live_weight)) OVER (), 2) AS pct_of_world
FROM fact_capture f
JOIN dim_country c ON f.country_id = c.country_id
WHERE f.environment_id = 'MA' AND f.prod_year = 2024
GROUP BY c.country_name, c.continent, c.economic_class
ORDER BY tonnes DESC
LIMIT 10;

-- 3. Which countries grew / shrank most between 2010 and 2024 (only countries > 100 kt in 2010)
SELECT c.country_name,
       ROUND(a.t / 1e3, 1) AS kt_2010,
       ROUND(b.t / 1e3, 1) AS kt_2024,
       ROUND((b.t - a.t) / a.t * 100, 1) AS change_pct
FROM (SELECT country_id, SUM(tonnes_live_weight) AS t FROM fact_capture
      WHERE environment_id = 'MA' AND prod_year = 2010 GROUP BY country_id) a
JOIN (SELECT country_id, SUM(tonnes_live_weight) AS t FROM fact_capture
      WHERE environment_id = 'MA' AND prod_year = 2024 GROUP BY country_id) b ON a.country_id = b.country_id
JOIN dim_country c ON a.country_id = c.country_id
WHERE a.t > 100000
ORDER BY change_pct;

-- 4. Capture by ocean basin and decade (share of each decade)
SELECT x.decade, x.ocean_name, ROUND(x.t / 1e6, 2) AS million_tonnes,
       ROUND(100.0 * x.t / SUM(x.t) OVER (PARTITION BY x.decade), 1) AS pct_of_decade
FROM (
  SELECT CAST(FLOOR(prod_year / 10) * 10 AS INT) AS decade, ocean_name, SUM(tonnes) AS t
  FROM vw_marine_capture_area_year
  GROUP BY CAST(FLOOR(prod_year / 10) * 10 AS INT), ocean_name
) x
ORDER BY x.decade, million_tonnes DESC;

-- 5. Environment split (freshwater / brackish / marine) per decade
SELECT CAST(FLOOR(f.prod_year / 10) * 10 AS INT) AS decade, e.environment_name,
       ROUND(SUM(f.tonnes_live_weight) / 1e6, 2) AS million_tonnes
FROM fact_capture f
JOIN dim_environment e ON f.environment_id = e.environment_id
GROUP BY CAST(FLOOR(f.prod_year / 10) * 10 AS INT), e.environment_name
ORDER BY decade, million_tonnes DESC;

-- 6. Regional dependence: capture by continent and economic class (latest 5 years)
SELECT c.continent, c.economic_class, ROUND(SUM(f.tonnes_live_weight) / 5 / 1e6, 2) AS avg_million_tonnes_per_year
FROM fact_capture f
JOIN dim_country c ON f.country_id = c.country_id
WHERE f.environment_id = 'MA' AND f.prod_year BETWEEN 2020 AND 2024
GROUP BY c.continent, c.economic_class
ORDER BY avg_million_tonnes_per_year DESC;
