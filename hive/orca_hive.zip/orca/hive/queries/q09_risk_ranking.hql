-- ORCA | Q09 Integrated risk views for the dashboard / decision support
USE orca;

-- 1. Top 20 countries by composite risk (pollution + fishery dependence + decline + vulnerability)
SELECT country_name, continent, economic_class, risk_tier, risk_score,
       ROUND(pollution_score, 2) AS pollution, ROUND(dependence_score, 2) AS dependence,
       ROUND(decline_score, 2) AS decline, ROUND(vulnerability_score, 2) AS vulnerability,
       ROUND(recent_capture_t / 1e3, 0) AS recent_capture_kt, capture_trend_pct
FROM mart_country_exposure
ORDER BY risk_score DESC
LIMIT 20;

-- 2. Risk tier summary by continent
SELECT continent, risk_tier, COUNT(*) AS countries, ROUND(AVG(risk_score), 3) AS avg_score
FROM mart_country_exposure
GROUP BY continent, risk_tier
ORDER BY continent, avg_score DESC;

-- 3. Reef location ranking
SELECT location_name, risk_tier, risk_score, avg_sst_c, avg_ph, high_bleaching_share, heatwave_share, unknown_severity_share
FROM mart_climate_location_risk
ORDER BY risk_score DESC;

-- 4. Palk Bay coral site ranking
SELECT site_name, risk_tier, risk_score, avg_dhw, avg_bleaching_pct, bleached_share, el_nino_share
FROM mart_coral_site_risk
ORDER BY risk_score DESC;

-- 5. Economic exposure of the high / critical-risk countries: how much fish they catch (market-size proxy)
SELECT risk_tier, COUNT(*) AS countries,
       ROUND(SUM(recent_capture_t) / 1e6, 2) AS million_tonnes_per_year,
       ROUND(100.0 * SUM(recent_capture_t) / SUM(SUM(recent_capture_t)) OVER (), 1) AS pct_of_world_capture
FROM mart_country_exposure
GROUP BY risk_tier
ORDER BY million_tonnes_per_year DESC;

-- 6. Fish-area watch-list: areas currently >20% below their historic peak
SELECT area_name, ocean_name, ROUND(tonnes / 1e3, 0) AS kt_2024, pct_below_peak
FROM mart_fish_area_trend
WHERE prod_year = 2024 AND pct_below_peak > 20
ORDER BY pct_below_peak DESC;
