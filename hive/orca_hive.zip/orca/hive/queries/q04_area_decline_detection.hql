-- ORCA | Q04 FAO marine area trends and decline detection (uses mart_fish_area_trend)
USE orca;

-- 1. Latest-year snapshot per area: tonnage, YoY and distance from historic peak
SELECT area_name, ocean_name, ROUND(tonnes / 1e3, 0) AS kt, yoy_pct, pct_below_peak
FROM mart_fish_area_trend
WHERE prod_year = 2024
ORDER BY pct_below_peak DESC;

-- 2. Areas that dropped more than 10% in consecutive years in the last decade (early-warning flag)
SELECT a.area_name, a.prod_year, a.yoy_pct, b.yoy_pct AS next_year_yoy_pct
FROM mart_fish_area_trend a
JOIN mart_fish_area_trend b ON a.area_id = b.area_id AND b.prod_year = a.prod_year + 1
WHERE a.prod_year >= 2014 AND a.yoy_pct < -10 AND b.yoy_pct < -10
ORDER BY a.area_name, a.prod_year;

-- 3. Rolling 5-year average per area, and the 5-year change (smooths FAO year-to-year noise)
SELECT area_name, prod_year, ROUND(avg5 / 1e3, 0) AS rolling_5y_kt,
       ROUND((avg5 / LAG(avg5, 5) OVER (PARTITION BY area_id ORDER BY prod_year) - 1) * 100, 1) AS change_vs_5y_ago_pct
FROM (
  SELECT area_id, area_name, prod_year,
         AVG(tonnes) OVER (PARTITION BY area_id ORDER BY prod_year ROWS BETWEEN 4 PRECEDING AND CURRENT ROW) AS avg5
  FROM mart_fish_area_trend
) w
WHERE prod_year >= 2015
ORDER BY area_name, prod_year;

-- 4. Rank of areas by share of world marine capture in 2024
SELECT area_name, ocean_name,
       ROUND(100.0 * tonnes / SUM(tonnes) OVER (), 2) AS pct_of_world,
       RANK() OVER (ORDER BY tonnes DESC) AS rnk
FROM mart_fish_area_trend
WHERE prod_year = 2024
ORDER BY rnk;
