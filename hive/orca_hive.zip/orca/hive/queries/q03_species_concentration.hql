-- ORCA | Q03 Species and species-group analysis (marine capture)
USE orca;

-- 1. Top 20 species by cumulative marine capture since 2000 (unknown species ids kept, labelled)
SELECT COALESCE(s.species_name, CONCAT('UNMAPPED:', f.species_id)) AS species,
       s.isscaap_group,
       ROUND(SUM(f.tonnes_live_weight) / 1e6, 2) AS million_tonnes
FROM fact_capture f
LEFT JOIN dim_species s ON f.species_id = s.species_id
WHERE f.environment_id = 'MA' AND f.prod_year >= 2000
GROUP BY COALESCE(s.species_name, CONCAT('UNMAPPED:', f.species_id)), s.isscaap_group
ORDER BY million_tonnes DESC
LIMIT 20;

-- 2. Concentration risk: share of the top-10 species in each year (higher = riskier, less diverse catch)
SELECT r.prod_year,
       ROUND(100.0 * SUM(CASE WHEN r.rnk <= 10 THEN r.t ELSE 0 END) / SUM(r.t), 1) AS top10_share_pct,
       COUNT(*) AS species_count
FROM (
  SELECT prod_year, species_id, SUM(tonnes_live_weight) AS t,
         RANK() OVER (PARTITION BY prod_year ORDER BY SUM(tonnes_live_weight) DESC) AS rnk
  FROM fact_capture
  WHERE environment_id = 'MA'
  GROUP BY prod_year, species_id
) r
GROUP BY r.prod_year
ORDER BY r.prod_year;

-- 3. ISSCAAP groups: 2000-2004 vs 2020-2024 average yearly catch and change
SELECT COALESCE(s.isscaap_group, 'Unmapped species') AS isscaap_group,
       ROUND(SUM(CASE WHEN f.prod_year BETWEEN 2000 AND 2004 THEN f.tonnes_live_weight END) / 5 / 1e3, 0) AS avg_kt_2000_04,
       ROUND(SUM(CASE WHEN f.prod_year BETWEEN 2020 AND 2024 THEN f.tonnes_live_weight END) / 5 / 1e3, 0) AS avg_kt_2020_24,
       ROUND((SUM(CASE WHEN f.prod_year BETWEEN 2020 AND 2024 THEN f.tonnes_live_weight END)
            / SUM(CASE WHEN f.prod_year BETWEEN 2000 AND 2004 THEN f.tonnes_live_weight END) - 1) * 100, 1) AS change_pct
FROM fact_capture f
LEFT JOIN dim_species s ON f.species_id = s.species_id
WHERE f.environment_id = 'MA'
GROUP BY COALESCE(s.isscaap_group, 'Unmapped species')
HAVING SUM(CASE WHEN f.prod_year BETWEEN 2000 AND 2004 THEN f.tonnes_live_weight END) > 0
ORDER BY avg_kt_2020_24 DESC;

-- 4. Major groups (fish / crustacea / molluscs ...) share by decade
SELECT x.decade, x.major_group, ROUND(x.t / 1e6, 2) AS million_tonnes,
       ROUND(100.0 * x.t / SUM(x.t) OVER (PARTITION BY x.decade), 1) AS pct_of_decade
FROM (
  SELECT CAST(FLOOR(f.prod_year / 10) * 10 AS INT) AS decade,
         COALESCE(s.major_group, 'UNMAPPED') AS major_group,
         SUM(f.tonnes_live_weight) AS t
  FROM fact_capture f
  LEFT JOIN dim_species s ON f.species_id = s.species_id
  WHERE f.environment_id = 'MA'
  GROUP BY CAST(FLOOR(f.prod_year / 10) * 10 AS INT), COALESCE(s.major_group, 'UNMAPPED')
) x
ORDER BY x.decade, million_tonnes DESC;

-- 5. Species with the steepest decline from their own peak year (stocks worth a closer look)
--    only species that peaked above 50 kt, compared with the 2020-2024 average
SELECT sp.species, ROUND(sp.peak_kt, 0) AS peak_kt, sp.peak_year, ROUND(sp.recent_kt, 0) AS recent_kt,
       ROUND((sp.peak_kt - sp.recent_kt) / sp.peak_kt * 100, 1) AS pct_below_peak
FROM (
  SELECT y.species,
         MAX(y.kt) AS peak_kt,
         MAX(CASE WHEN y.kt = y.peak THEN y.prod_year END) AS peak_year,
         AVG(CASE WHEN y.prod_year BETWEEN 2020 AND 2024 THEN y.kt END) AS recent_kt
  FROM (
    SELECT t.species, t.prod_year, t.kt, MAX(t.kt) OVER (PARTITION BY t.species) AS peak
    FROM (
      SELECT COALESCE(s.species_name, f.species_id) AS species, f.prod_year,
             SUM(f.tonnes_live_weight) / 1e3 AS kt
      FROM fact_capture f
      LEFT JOIN dim_species s ON f.species_id = s.species_id
      WHERE f.environment_id = 'MA'
      GROUP BY COALESCE(s.species_name, f.species_id), f.prod_year
    ) t
  ) y
  GROUP BY y.species
) sp
WHERE sp.peak_kt > 50
ORDER BY pct_below_peak DESC
LIMIT 20;
