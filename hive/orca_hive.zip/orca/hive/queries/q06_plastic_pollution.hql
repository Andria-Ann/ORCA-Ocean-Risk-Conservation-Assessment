-- ORCA | Q06 Plastic pollution pressure (2010 snapshot) and link to income / region
USE orca;

-- 1. Top 15 countries by share of global mismanaged plastic waste, with running cumulative share
SELECT t.country_name, t.mismanaged_pct_of_global,
       ROUND(SUM(t.mismanaged_pct_of_global) OVER (ORDER BY t.mismanaged_pct_of_global DESC
                                                   ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW), 2) AS cumulative_pct
FROM plastic_country_2010 t
ORDER BY t.mismanaged_pct_of_global DESC
LIMIT 15;

-- 2. Pollution by continent and World Bank income class
SELECT c.continent, c.economic_class, COUNT(*) AS countries,
       ROUND(SUM(p.mismanaged_pct_of_global), 2) AS pct_of_global_mismanaged,
       ROUND(AVG(p.plastic_waste_kg_pp_day), 3)  AS avg_waste_kg_pp_day,
       ROUND(AVG(p.mismanaged_kg_pp_day), 3)     AS avg_mismanaged_kg_pp_day
FROM plastic_country_2010 p
JOIN dim_country c ON p.iso3 = c.iso3
GROUP BY c.continent, c.economic_class
ORDER BY pct_of_global_mismanaged DESC;

-- 3. GDP bands: richer countries make more waste per person but mismanage less of it
SELECT CASE WHEN gdp_per_capita_ppp < 2000 THEN '1: <2k'
            WHEN gdp_per_capita_ppp < 5000 THEN '2: 2-5k'
            WHEN gdp_per_capita_ppp < 15000 THEN '3: 5-15k'
            WHEN gdp_per_capita_ppp < 40000 THEN '4: 15-40k'
            ELSE '5: 40k+' END AS gdp_band,
       COUNT(*) AS countries,
       ROUND(AVG(plastic_waste_kg_pp_day), 3) AS avg_waste_kg_pp_day,
       ROUND(AVG(mismanaged_kg_pp_day), 3)    AS avg_mismanaged_kg_pp_day,
       ROUND(AVG(mismanaged_kg_pp_day / NULLIF(plastic_waste_kg_pp_day, 0)) * 100, 1) AS avg_pct_of_waste_mismanaged
FROM plastic_country_2010
WHERE gdp_per_capita_ppp IS NOT NULL
GROUP BY CASE WHEN gdp_per_capita_ppp < 2000 THEN '1: <2k'
              WHEN gdp_per_capita_ppp < 5000 THEN '2: 2-5k'
              WHEN gdp_per_capita_ppp < 15000 THEN '3: 5-15k'
              WHEN gdp_per_capita_ppp < 40000 THEN '4: 15-40k'
              ELSE '5: 40k+' END
ORDER BY gdp_band;

-- 4. Correlations: what predicts mismanagement?
SELECT ROUND(CORR(gdp_per_capita_ppp, plastic_waste_kg_pp_day), 3)  AS corr_gdp_waste,
       ROUND(CORR(gdp_per_capita_ppp, mismanaged_kg_pp_day), 3)     AS corr_gdp_mismanaged,
       ROUND(CORR(population, mismanaged_pct_of_global), 3)         AS corr_population_global_share
FROM plastic_country_2010;

-- 5. Hotspots: high mismanaged waste AND high marine capture (fisheries most exposed to plastic)
SELECT country_name, continent, ROUND(mismanaged_pct_of_global, 2) AS pct_global_mismanaged,
       ROUND(recent_capture_t / 1e3, 0) AS recent_capture_kt, risk_tier
FROM mart_country_exposure
WHERE mismanaged_pct_of_global >= 1 AND recent_capture_t >= 100000
ORDER BY mismanaged_pct_of_global DESC;

-- 6. World plastic production growth (CAGR over 5-year windows)
SELECT obs_year, production_million_tonnes,
       ROUND((POWER(production_million_tonnes / LAG(production_million_tonnes, 5) OVER (ORDER BY obs_year), 1.0 / 5) - 1) * 100, 2) AS cagr_5y_pct
FROM plastic_production_global
ORDER BY obs_year;
