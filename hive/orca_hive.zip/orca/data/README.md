# data/ — dataset documentation

`Datas.xlsx` holds 18 sheets. `prepare_csv.py` converts each into `data/csv/<name>.csv` (not committed, regenerated);
`data/sample/` holds the first 100 rows of each for review.

| Sheet → CSV | Content | Rows |
|---|---|---|
| dim_country, dim_area, dim_species, dim_environment, dim_measure, dim_status | FAO-style code lists | 251, 19, 9,531, 4, 5, 16 |
| fact_capture, fact_aquaculture | production (t live weight) by country x species x FAO area x environment x year, 1950-2024 | 107,419 each |
| ocean_climate | 500 observations, 7 reef locations: SST, pH, bleaching severity, species count, heatwave flag | 500 |
| coral_cleaned | Palk Bay / Gulf of Mannar sites: temp, SSTA, DHW, hotspot, ONI/ENSO, bleaching %, water quality | 2,000 |
| economy_cleaned | marine economy by sector (GDP, earnings, jobs, shares) 2007-2021 | 714 |
| chlorophyll_cleaned | bacteria / protozoa / phytoplankton by depth and transect (Southern Ocean coordinates) | 263 |
| cast_cleaned | oceanographic cast archive, 61 columns (CalCOFI-style), 1949-2016 | 34,404 |
| global_plastics_production | world plastics production 1950-2015 (million t) | 66 |
| mismanaged_waste_global, plastic_waste_per_capita | country share of global mismanaged plastic, per-capita waste (2010) | 186 each |
| per_capita_mismanaged_plastic, per_capita_plastic_waste_gdp | 2010 per-capita values with GDP (PPP) and population | 148 each |

## Sources and licences — TO CONFIRM
The project rule is to use appropriately licensed data and document sources. The workbook does not record its
origin. From column names and structure the data looks derived from: FAO FishStat (fisheries/aquaculture),
Our World in Data / Jambeck et al. 2015 (plastic), CalCOFI (casts), NOAA Coral Reef Watch-style indices (DHW, hotspot),
and a national marine-economy statistics release. `ocean_climate` and `coral_cleaned` look synthetic
(the sheet is literally called "realistic_ocean_climate_dataset"). **Each owner must confirm source URL, licence and
whether data is real or synthetic, then fill this table before the report.**

## Cleaning notes
Headers → snake_case; `dim_species`, `dim_status`, `dim_enviornment` had their real header on row 2; dates → ISO;
the `Unkown` typo is fixed in the Hive clean layer, not in the CSV (raw stays raw).
