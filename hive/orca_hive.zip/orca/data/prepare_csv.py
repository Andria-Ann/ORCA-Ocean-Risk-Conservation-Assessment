#!/usr/bin/env python3
"""Convert Datas.xlsx (one sheet per table) into clean CSV files ready for HDFS/Hive.

Usage:  python3 data/prepare_csv.py Datas.xlsx data/csv

What it does
  * one CSV per sheet, snake_case headers, UTF-8, comma separated, header row kept
    (Hive raw tables skip it with skip.header.line.count=1)
  * dim_species / dim_status / dim_enviornment: real header is on row 2 (row 1 is "Column1..N")
  * dates written as ISO yyyy-mm-dd, line breaks inside cells replaced by a space
  * empty cells stay empty (Hive turns them into NULL when casting)
Requires: pandas, openpyxl
"""
import re
import sys
from datetime import date, datetime
from pathlib import Path

import pandas as pd

RENAME = {
    "cleaned_global_plastics_product": "global_plastics_production",
    "cleaned_mismanaged_waste_global": "mismanaged_waste_global",
    "cleaned_per_capita_mismanaged_p": "per_capita_mismanaged_plastic",
    "cleaned_per_capita_plastic_wast": "per_capita_plastic_waste_gdp",
    "realistic_ocean_climate_dataset": "ocean_climate",
    "dim_enviornment": "dim_environment",
}
HEADER_ON_ROW_2 = {"dim_species", "dim_status", "dim_enviornment"}


def snake(col: str) -> str:
    col = str(col).lower().replace("°c", "c").replace("%", "pct")
    return re.sub(r"[^a-z0-9]+", "_", col).strip("_")


def main(xlsx: str, out_dir: str) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    book = pd.ExcelFile(xlsx)
    for sheet in book.sheet_names:
        header = 1 if sheet in HEADER_ON_ROW_2 else 0
        df = book.parse(sheet, header=header, dtype=object)
        df.columns = [snake(c) for c in df.columns]
        df = df.loc[:, [c for c in df.columns if c and not c.startswith("unnamed")]]
        for c in df.columns:  # datetime cells -> ISO date text
            df[c] = df[c].map(lambda v: v.strftime("%Y-%m-%d") if isinstance(v, (datetime, date)) else v)
        df = df.replace(r"[\r\n]+", " ", regex=True)
        name = RENAME.get(sheet, sheet.lower())
        df.to_csv(out / f"{name}.csv", index=False)
        print(f"{name:34s} {len(df):>8,} rows  {len(df.columns):>3} cols")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2])
